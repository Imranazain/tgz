# Written By Qaiser
# Donot recode it 

##Commands##
pkg update && upgrade
pkg install git
pkg install python2
pip2 install requests
pip2 install mechanize
git clone https://github.com/TechQaiser/M500
ls
cd M500
ls
python2 M500.py

##Username-Pass##
Username : Qaiser
Password : M500

#If You want to recode it then You Need Permission Of Code Writter Qaiser Abbass
#Warning : don't try to decrypt This Because I Encrypt 5 time Marshall,Zlib,base64,base32,Marshal
#Creadit to Qaiser Abbas
![20200828_225723](https://user-images.githubusercontent.com/69212320/91600966-445a2480-e982-11ea-86e8-436ff3c5f22a.png)

![119813](https://user-images.githubusercontent.com/69212320/91600995-550a9a80-e982-11ea-9001-f84a7552967e.gif)

![200w](https://user-images.githubusercontent.com/69212320/91599508-e9273280-e97f-11ea-8589-ca94b94ea335.gif)
